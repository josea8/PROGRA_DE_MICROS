/*
 * PWM2.h
 *
 * Created: 21/05/2024 21:12:42
 *  Author: Jose
 */ 


#ifndef PWM2_H_
#define PWM2_H_


#include <stdint.h>
#include <avr/io.h>

void init_PWM2_FAST(void);
void updateDutyCicle2A(uint8_t duty);
void updateDutyCicle2B(uint8_t duty);



#endif /* PWM2_H_ */