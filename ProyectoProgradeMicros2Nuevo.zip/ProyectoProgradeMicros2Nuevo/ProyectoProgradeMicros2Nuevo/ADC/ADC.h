/*
 * ADC.h
 *
 * Created: 21/05/2024 14:34:27
 *  Author: Jose
 */ 


#ifndef ADC_H_
#define ADC_H_


#include <stdint.h>
#include <avr/io.h>
#include <avr/interrupt.h>
void initADC(void);





#endif /* ADC_H_ */