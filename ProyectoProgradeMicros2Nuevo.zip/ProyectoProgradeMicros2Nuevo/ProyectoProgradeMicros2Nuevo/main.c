/*
 * ProyectoProgradeMicros2.c
 *
 * Created: 21/05/2024 14:07:02
 * Author : Jose
 */ 


#define F_CPU 4000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "ADC/ADC.h"
#include "PWM1/PWM1.h"
#include "PWM2/PWM2.h"
// DECLARACION DE FUNCIONES
void setup(void);
void initUART9600(void);
void writeUART(char Caracter);
void WriteTextUART(char * Texto);
void Menu(void);


// DECLARACION DE VARIABLES
volatile uint8_t bufferTX;
uint8_t valorADC = 0x00;
uint8_t modov = 0;
bool opcion = false;
uint8_t POT1V = 0;
uint16_t dutyCycle1 = 0;
uint8_t POT2V = 0;
uint8_t dutyCycle2 = 0;
uint8_t POT3V = 0;
uint8_t dutyCycle3 = 0;
uint8_t POT4V = 0;
uint8_t dutyCycle4 = 0;
uint8_t cambiapot = 0;

//---------FUNCIONES-----------------------------------------------------------------------------------------
uint16_t moverservo1(uint8_t VADC1){
	return (uint16_t)(((float)VADC1/255)*(149.88-37.47)+37.47);
}

uint16_t moverservo2(uint8_t VADC2){
	return (uint16_t)(((float)VADC2/255)*(149.88-37.47)+37.47);
}

uint8_t moverservo3(uint8_t VADC3){
	return (uint8_t)(((float)VADC3/255)*(31-5)+5);
}

uint8_t moverservo4(uint8_t VADC4){
	return (uint8_t)(((float)VADC4/255)*(31-5)+5);
}

void setup(){
	cli();
	DDRC = 0;
	DDRC |= (1<<DDD1)|(1<<DDD2)|(1<<DDD3);
	DDRC |= (0<<DDD0);
	DDRC |= (1<<DDD0);
	PCICR |= (1<<PCIE1);
	PCMSK1 |= (1<<PCINT8);
	initUART9600();
	init_PWM1_FAST();
	init_PWM2_FAST();
	initADC();
	sei();
}

void initUART9600(){
	// RX COMO ENTRADA Y TX COMO SALIDA
	DDRD &= ~(1<<DDD0);
	DDRD |= (1<<DDD1);
	
	// CONFIGURAR UCSR0A
	UCSR0A = 0;
	
	// CONFIGURAR UCSR0B DONDE SE HABILITA LA ISR DE RECEPCION
	UCSR0B = 0;
	UCSR0B |= (1<<RXCIE0) | (1<<RXEN0) | (1<<TXEN0);
	
	// CONFIGURAR UCSR0C
	UCSR0C = 0;
	
	// CONFIGURAR AASINCRONO Y SIN PARIDAD, 1 BIT DE PARADA
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
	
	// BAUD DE 103
	UBRR0 = 103;
}

void writeUART(char Caracter){
	while (!(UCSR0A & (1<<UDRE0)));
	UDR0 = Caracter;
}

void WriteTextUART(char * Texto){
	uint8_t i;
	for (i=0; Texto[i]!= '\0'; i++){
		while (!(UCSR0A & (1<<UDRE0)) );
		UDR0 = Texto[i];
	}
}

void Menu(){
	
	writeUART(10);
	writeUART(13);
	WriteTextUART("Proyecto progra de micros 2, seleccione una opci�n");
	writeUART(10);
	writeUART(13);
	WriteTextUART("1. Modo EEPROM");
	writeUART(10);
	writeUART(13);
	WriteTextUART("2. Modo UART");
	writeUART(10);
	writeUART(13);
}


int main(void)
{
	CLKPR = (1<<CLKPCE);
	CLKPR = (1<<CLKPS1); // CLK 4 MHz
	setup();
	Menu();
	
	while (1) {
		if (modov == 0)
		{
			dutyCycle1 = moverservo1(POT1V);
			updateDutyCicle1A(dutyCycle1);
			
			
			dutyCycle2 = moverservo2(POT2V);
			updateDutyCicle1B(dutyCycle2);
			
			
			dutyCycle3 = moverservo3(POT3V);
			updateDutyCicle2A(dutyCycle3);
			
			
			dutyCycle4 = moverservo4(POT4V);
			updateDutyCicle2B(dutyCycle4);
			
			PORTC &= ~(1<<PINC3);//valor del modo en la led
			PORTC |= (1<<PINC1);
		}
		else if (modov == 1){
			PORTC &= ~(1<<PINC1);
			PORTC |= (1<<PINC2);
		}
		else if (modov == 2){
			PORTC &= ~(1<<PINC2);
			PORTC |= (1<<PINC3);
		}
	}
	
}

//---------INTERRUPCIONES---------

ISR(USART_RX_vect){
	
	bufferTX = UDR0;
	while (!(UCSR0A & (1<<UDRE0)));
	
	if (modov == 0){
		
		if (bufferTX == 49){	// PRESIONO 1
			writeUART(10);
			writeUART(13);
			PORTC = (1<<DDC0);
			modov = 1;
			WriteTextUART("Esta en el modo EEPROM");
			writeUART(10);
			writeUART(13);
			WriteTextUART("Presionar ESC para salir");
			writeUART(10);
			writeUART(13);
		}
		else if (bufferTX == 50){	// PRESIONO 2
			writeUART(10);
			writeUART(13);
			PORTC = (1<<DDC1);
			modov = 2;
			WriteTextUART("Esta en el modo UART");
			writeUART(10);
			writeUART(13);
			WriteTextUART("Presionar ESC para salir");
			writeUART(10);
			writeUART(13);
		}
		else {
			WriteTextUART("PRESIONA UN VALOR QUE SI SEA ACEPTABLE");
			writeUART(10);
			writeUART(13);
			Menu();
		}

	}
	
	else if (modov == 1){
		if (bufferTX == 27){
			PORTC = 0;
			modov = 0;
			Menu();
		}
		else {
			WriteTextUART("Sigue en el modo EEPROM");
			writeUART(10);
			writeUART(13);
		}
	}
	
	else if (modov == 2){
		if (bufferTX == 27){
			PORTC = 0;
			modov = 0;
			Menu();
		}
		else {
			WriteTextUART("Sigue en el Modo UART");
			writeUART(10);
			writeUART(13);
		}
	}
	
}
ISR(ADC_vect){
	ADCSRA &= ~(1<<ADEN);
	if (cambiapot == 0)
	{
		ADMUX = ((ADMUX & ~((1<<MUX2)|(1<<MUX1)|(1<<MUX0))) | ((1<<MUX2)|(1<<MUX1)|(1<<MUX0)));
		POT1V = ADCH;
		cambiapot +=1;
	}
	else if (cambiapot == 1)
	{
		ADMUX = ((ADMUX & ~((1<<MUX2)|(1<<MUX1)|(1<<MUX0))) | ((1<<MUX2)|(1<<MUX1)));
		POT2V = ADCH;
		cambiapot +=1;
	}
	else if (cambiapot == 2)
	{
		ADMUX = ((ADMUX & ~((1<<MUX2)|(1<<MUX1)|(1<<MUX0))) | ((1<<MUX2)|(1<<MUX0)));
		POT3V = ADCH;
		cambiapot +=1;
	}
	else if (cambiapot == 3)
	{
		ADMUX = ((ADMUX & ~((1<<MUX2)|(1<<MUX1)|(1<<MUX0))) | (1<<MUX2));
		POT4V = ADCH;
		cambiapot = 0;
	}
	ADCSRA |= (1<<ADEN);
	ADCSRA |= (1<<ADSC);
	ADCSRA |= (1<<ADIF);

}
ISR (PCINT1_vect){
	if (!(PINC & (1 << PINC0))) {
		_delay_ms(100); // Debouncing delay
		if (!(PINC & (1 << PINC0))) { // Verifica nuevamente si el bot�n est� presionado
			modov++; // Incrementa la variable modo
			if (modov >= 3) { // Si modo alcanza 3, rein�cialo a 0
				modov = 0;
			}
		}
	}
}